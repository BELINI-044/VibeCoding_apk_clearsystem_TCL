# Personalizacao ClearSystem TCL v3

Base: simbasjungles/free-my-tv, commit a6c128da484d8824064f4be143913e9fce0b2f07.
Este arquivo exporta o codigo atual completo, sem .git, out, APKs, config.properties ou chaves privadas.
Mantem os avisos de licenca e o README original. A documentacao da distribuicao esta em README-ClearSystem.md.

Mudancas: UNITV primeiro quando instalado; dock com foco branco e nome; relogio menor; cotacoes ocultas uma vez;
tema escuro aplicado uma vez; imagem de fundo local em app/assets/backgrounds/midnight.png;
painel TvResourcesActivity com entradas e menus publicos; botoes para abrir o painel na HomeApps.
HomeMode, RemoteKeys e RemoteKeyService nao foram alterados.

Build Android: JDK 17, SDK platform 34, build-tools 34.0.0. Para o perfil do binario, copie
config.cianorte.example.properties para config.properties; opcionalmente ajuste sua cidade/idioma. Execute bash build.sh.
O build cria sua propria chave local quando ela nao existe. Guarde-a privadamente para atualizacoes futuras.
Uma assinatura diferente nao substitui uma instalacao existente. O keystore do APK distribuido nao acompanha os fontes.

Verificacoes: bash tools/check.sh passou (Android, traducoes 410 chaves, 48 assercoes de controle, web/LG/Tizen).
O instalador Windows foi testado por parser PowerShell e 17 cenarios simulados no Linux.
V3 ainda aguarda teste visual/funcional na TV. O pacote nao instala outros apps nem altera controles ou ajustes.

Os arquivos windows/ mostram o codigo do instalador do pacote. Para usa-lo, baixe o ZIP de atualizacao,
que inclui o APK assinado e as ferramentas oficiais do Android, e use a pasta extraida completa.
