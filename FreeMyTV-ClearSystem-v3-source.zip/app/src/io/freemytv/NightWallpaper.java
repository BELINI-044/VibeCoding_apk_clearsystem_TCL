package io.freemytv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One shared, sampled night image: no decoding on the UI thread or continuous animation. */
final class NightWallpaper extends Drawable {
    private static final ExecutorService LOADER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile Bitmap image;
    private static boolean attempted;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final Rect source = new Rect();
    private int imageWidth;

    NightWallpaper(Context context) {
        this(context, null);
    }

    NightWallpaper(Context context, Runnable ready) {
        Context app = context.getApplicationContext();
        LOADER.execute(() -> {
            // All callers share this executor and one bitmap, including the resources panel.
            if (!attempted) {
                attempted = true;
                try (InputStream in = app.getAssets().open("backgrounds/midnight.png")) {
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = 2;
                    options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    image = BitmapFactory.decodeStream(in, null, options);
                } catch (IOException | RuntimeException | OutOfMemoryError e) {
                    AppLog.w("night wallpaper unavailable: " + e.getClass().getSimpleName());
                }
            }
            MAIN.post(() -> {
                invalidateSelf();
                if (ready != null) ready.run();
            });
        });
    }

    @Override protected void onBoundsChange(Rect bounds) {
        imageWidth = 0;
    }

    @Override public void draw(Canvas canvas) {
        int alpha = paint.getAlpha();
        paint.setColor(0xFF030913);
        paint.setAlpha(alpha);
        canvas.drawRect(getBounds(), paint);
        Bitmap bitmap = image;
        Rect bounds = getBounds();
        if (bitmap == null || bounds.isEmpty()) return;
        if (imageWidth != bitmap.getWidth()) {
            imageWidth = bitmap.getWidth();
            float scale = Math.max((float) bounds.width() / bitmap.getWidth(),
                    (float) bounds.height() / bitmap.getHeight());
            int sw = Math.max(1, Math.min(bitmap.getWidth(), Math.round(bounds.width() / scale)));
            int sh = Math.max(1, Math.min(bitmap.getHeight(), Math.round(bounds.height() / scale)));
            int left = (bitmap.getWidth() - sw) / 2, top = (bitmap.getHeight() - sh) / 2;
            source.set(left, top, left + sw, top + sh);
        }
        canvas.drawBitmap(bitmap, source, bounds, paint);
    }

    @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
    @Override public int getOpacity() { return paint.getAlpha() == 255 ? PixelFormat.OPAQUE : PixelFormat.TRANSLUCENT; }
}
