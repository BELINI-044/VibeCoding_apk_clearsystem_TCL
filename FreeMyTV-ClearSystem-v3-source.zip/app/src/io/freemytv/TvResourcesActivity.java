package io.freemytv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** A lightweight hub for public inputs and settings; it never writes system settings or requests ADB. */
public final class TvResourcesActivity extends Activity {
    private static final int INK = 0xFFF0F5FA, DIM = 0xFFAFBED0, FOCUS_INK = 0xFF081A27;
    private LinearLayout inputRows, settingRows;
    private String focusedKey = "";
    private int generation;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.init(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(40), dp(26), dp(40), dp(24));
        root.setBackground(new NightWallpaper(this));
        root.addView(text(Ui.tr("TV Resources"), 28, INK));
        TextView subtitle = text(Ui.tr("Inputs and settings in one place."), 14, DIM);
        LinearLayout.LayoutParams caption = new LinearLayout.LayoutParams(-1, -2);
        caption.topMargin = dp(6);
        caption.bottomMargin = dp(20);
        root.addView(subtitle, caption);

        LinearLayout columns = new LinearLayout(this);
        columns.setOrientation(LinearLayout.HORIZONTAL);
        inputRows = column(columns, Ui.tr("Inputs"), false);
        settingRows = column(columns, Ui.tr("TV Settings"), true);
        root.addView(columns, new LinearLayout.LayoutParams(-1, 0, 1));
        inputRows.addView(text(Ui.tr("Starting…"), 16, DIM));
        setContentView(root);
    }

    private LinearLayout column(LinearLayout parent, String title, boolean right) {
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        TextView heading = text(title, 15, DIM);
        LinearLayout.LayoutParams headingSize = new LinearLayout.LayoutParams(-1, -2);
        headingSize.bottomMargin = dp(10);
        column.addView(heading, headingSize);
        ScrollView scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows, new ScrollView.LayoutParams(-1, -2));
        column.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams size = new LinearLayout.LayoutParams(0, -1, 1);
        if (right) size.leftMargin = dp(24);
        parent.addView(column, size);
        return rows;
    }

    @Override protected void onResume() {
        super.onResume();
        int stamp = ++generation;
        new Thread(() -> {
            List<Entry> inputs = new ArrayList<>(), settings = new ArrayList<>();
            try {
                for (HomeApps.Item item : HomeApps.allInputs(this)) inputs.add(new Entry(item));
            } catch (RuntimeException e) {
                AppLog.w("resource inputs unavailable: " + e.getClass().getSimpleName());
            }
            settings.add(setting("storage", Ui.tr("Storage"), "usb", Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
                    "com.android.tv.settings.device.StorageResetActivity"));
            settings.add(setting("sound", Ui.tr("Sound"), "speaker", Settings.ACTION_SOUND_SETTINGS,
                    "com.android.tv.settings.device.sound.SoundActivity"));
            settings.add(setting("settings", Ui.tr("TV Settings"), "tv_settings", Settings.ACTION_SETTINGS,
                    "com.android.tv.settings.MainSettings"));
            runOnUiThread(() -> {
                if (stamp != generation || isFinishing() || isDestroyed()) return;
                populate(inputs, settings);
            });
        }, "tv-resources").start();
    }

    @Override protected void onPause() {
        generation++;
        super.onPause();
    }

    private Entry setting(String key, String label, String symbol, String action, String fallback) {
        Entry entry = new Entry(key, label, symbol);
        try {
            Intent intent = new Intent(action).setPackage("com.android.tv.settings");
            ResolveInfo resolved = getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
            if (accessible(resolved)) {
                ActivityInfo info = resolved.activityInfo;
                entry.intent = intent.setComponent(new ComponentName(info.packageName, info.name));
            } else {
                intent = new Intent(action).setComponent(new ComponentName("com.android.tv.settings", fallback));
                if (accessible(getPackageManager().resolveActivity(intent, 0))) entry.intent = intent;
            }
        } catch (RuntimeException e) {
            AppLog.w("resource setting unavailable: " + key);
        }
        return entry;
    }

    private boolean accessible(ResolveInfo resolved) {
        if (resolved == null || resolved.activityInfo == null) return false;
        ActivityInfo info = resolved.activityInfo;
        return info.enabled && info.exported && info.applicationInfo != null && info.applicationInfo.enabled
                && !info.name.startsWith("com.android.internal.app.")
                && (info.permission == null || checkSelfPermission(info.permission) == PackageManager.PERMISSION_GRANTED);
    }

    private void populate(List<Entry> inputs, List<Entry> settings) {
        inputRows.removeAllViews();
        settingRows.removeAllViews();
        List<View> left = addRows(inputRows, inputs), right = addRows(settingRows, settings);
        if (left.isEmpty()) inputRows.addView(text(Ui.tr("No inputs reported."), 16, DIM));
        connectFocus(left, right, true);
        connectFocus(right, left, false);
        View selected = null;
        for (int side = 0; side < 2; side++) {
            List<View> rows = side == 0 ? left : right;
            for (View row : rows) if (focusedKey.equals(row.getTag())) selected = row;
        }
        if (selected == null) selected = left.isEmpty() ? right.get(0) : left.get(0);
        selected.requestFocus();
    }

    private List<View> addRows(LinearLayout parent, List<Entry> entries) {
        List<View> rows = new ArrayList<>();
        for (Entry entry : entries) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(8), dp(16), dp(8));
            row.setId(View.generateViewId());
            row.setTag(entry.key);
            row.setFocusable(true);
            row.setClickable(true);
            boolean available = entry.input != null || entry.intent != null;
            boolean noSignal = entry.input != null && entry.input.kind == HomeApps.INPUT && !entry.input.connected;
            String detail = !available ? Ui.tr("Unavailable") : noSignal ? Ui.tr("No signal") : "";
            row.setContentDescription(entry.label + (detail.isEmpty() ? "" : ", " + detail));
            row.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            Glyph glyph = new Glyph(entry.symbol);
            row.addView(glyph, new LinearLayout.LayoutParams(dp(28), dp(28)));
            LinearLayout captions = new LinearLayout(this);
            captions.setOrientation(LinearLayout.VERTICAL);
            captions.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            TextView label = text(entry.label, 17, INK);
            label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            captions.addView(label);
            TextView hint = text(detail, 12, DIM);
            if (!detail.isEmpty()) captions.addView(hint);
            LinearLayout.LayoutParams space = new LinearLayout.LayoutParams(0, -2, 1);
            space.leftMargin = dp(16);
            row.addView(captions, space);
            GradientDrawable normal = shape(0xE612202E, 0xFF294454);
            GradientDrawable focused = shape(0xFFF0F7FA, 0xFF75D8D1);
            row.setBackground(normal);
            if (!available) row.setAlpha(0.55f);
            row.setOnFocusChangeListener((v, hasFocus) -> {
                if (hasFocus) focusedKey = entry.key;
                row.setBackground(hasFocus ? focused : normal);
                label.setTextColor(hasFocus ? FOCUS_INK : INK);
                hint.setTextColor(hasFocus ? 0xFF3C5668 : DIM);
                glyph.ink = hasFocus ? FOCUS_INK : INK;
                glyph.invalidate();
            });
            row.setOnClickListener(v -> open(entry));
            LinearLayout.LayoutParams size = new LinearLayout.LayoutParams(-1, dp(64));
            size.bottomMargin = dp(8);
            parent.addView(row, size);
            rows.add(row);
        }
        return rows;
    }

    private void connectFocus(List<View> rows, List<View> other, boolean left) {
        for (int i = 0; i < rows.size(); i++) {
            View row = rows.get(i);
            row.setNextFocusUpId(rows.get(Math.max(0, i - 1)).getId());
            row.setNextFocusDownId(rows.get(Math.min(rows.size() - 1, i + 1)).getId());
            int across = other.isEmpty() ? row.getId() : other.get(Math.min(i, other.size() - 1)).getId();
            row.setNextFocusLeftId(left ? row.getId() : across);
            row.setNextFocusRightId(left ? across : row.getId());
        }
    }

    private void open(Entry entry) {
        if (entry.input != null) {
            if (!HomeApps.open(this, entry.input, null)) unavailable(entry.label);
        } else if (entry.intent == null) {
            Toast.makeText(this, Ui.tr("Unavailable"), Toast.LENGTH_SHORT).show();
        } else {
            try { startActivity(new Intent(entry.intent)); }
            catch (ActivityNotFoundException | SecurityException e) { unavailable(entry.label); }
        }
    }

    private void unavailable(String label) {
        Toast.makeText(this, Ui.trf("Couldn't open {app}.", "app", label), Toast.LENGTH_LONG).show();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTypeface(Ui.medium);
        view.setTextColor(color);
        return view;
    }

    private GradientDrawable shape(int fill, int border) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(12));
        drawable.setStroke(dp(1), border);
        return drawable;
    }

    private final class Glyph extends View {
        private final String symbol;
        private int ink = INK;
        Glyph(String symbol) {
            super(TvResourcesActivity.this);
            this.symbol = symbol;
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }
        @Override protected void onDraw(Canvas canvas) {
            Symbols.draw(getContext(), canvas, symbol, getWidth() / 2f, getHeight() / 2f,
                    Math.min(getWidth(), getHeight()), ink);
        }
    }

    private static final class Entry {
        final String key, label, symbol;
        HomeApps.Item input;
        Intent intent;
        Entry(String key, String label, String symbol) { this.key = key; this.label = label; this.symbol = symbol; }
        Entry(HomeApps.Item input) { this(input.key, input.label, input.symbol); this.input = input; }
    }
}
