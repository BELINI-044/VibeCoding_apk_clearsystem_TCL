@echo off
setlocal DisableDelayedExpansion
set "TCL_DIAGNOSTIC_FILE=%~f0"
powershell.exe -NoLogo -NoProfile -Command "$text = [System.IO.File]::ReadAllText($env:TCL_DIAGNOSTIC_FILE); $marker = '# POWERSHELL_START'; $pos = $text.LastIndexOf($marker); if ($pos -lt 0) { Write-Host 'Arquivo incompleto. Baixe o pacote novamente.'; exit 1 }; & ([ScriptBlock]::Create($text.Substring($pos + $marker.Length)))"
set "TCL_DIAGNOSTIC_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %TCL_DIAGNOSTIC_EXIT%
# POWERSHELL_START
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$serial = '192.168.1.102:5555'
$script:queryCount = 0
$script:okCount = 0
$script:partialCount = 0
$script:unavailableCount = 0
$script:report = New-Object 'System.Collections.Generic.List[string]'

function ConvertTo-NativeArgument {
    param([string] $Value)
    if ($Value.Length -gt 0 -and $Value -notmatch '[\s"]') { return $Value }
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return '"' + $escaped + '"'
}

function Invoke-Adb {
    param([string[]] $Arguments)
    $start = New-Object System.Diagnostics.ProcessStartInfo
    $start.FileName = $script:adb
    $start.Arguments = (($Arguments | ForEach-Object { ConvertTo-NativeArgument $_ }) -join ' ')
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $start
    try {
        [void] $process.Start()
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        if (!$process.WaitForExit(15000)) {
            try { $process.Kill() } catch { }
            [void] $process.WaitForExit(2000)
            return [PSCustomObject]@{ ExitCode = -1; TimedOut = $true; Text = ''; ErrorText = '' }
        }
        if (!$stdout.Wait(1000) -or !$stderr.Wait(1000)) {
            return [PSCustomObject]@{ ExitCode = -1; TimedOut = $true; Text = ''; ErrorText = '' }
        }
        return [PSCustomObject]@{
            ExitCode = $process.ExitCode; TimedOut = $false
            Text = $stdout.Result; ErrorText = $stderr.Result
        }
    } finally { $process.Dispose() }
}

function Add-Report {
    param([string] $Value)
    $script:report.Add($Value)
}

function Read-Query {
    param([string] $Title, [string] $Command, [ScriptBlock] $Parser,
          [int[]] $PartialExitCodes = @())
    $script:queryCount++
    Write-Host ('Consultando: ' + $Title)
    Add-Report ''
    Add-Report ('[' + $Title + ']')
    $result = Invoke-Adb -Arguments @('-s', $serial, 'shell', $Command)
    if ($result.TimedOut) {
        $script:unavailableCount++
        Add-Report 'INDISPONIVEL: consulta excedeu 15 segundos; nao foi repetida.'
        return
    }
    $partial = $result.ExitCode -ne 0 -and $PartialExitCodes -contains $result.ExitCode
    if ($result.ExitCode -ne 0 -and !$partial) {
        $script:unavailableCount++
        Add-Report ('INDISPONIVEL: comando retornou codigo ' + $result.ExitCode + '.')
        return
    }
    $items = @(& $Parser $result.Text)
    if ($items.Count -eq 0) {
        $script:unavailableCount++
        Add-Report 'INDISPONIVEL: resposta vazia ou em formato nao reconhecido.'
        return
    }
    if ($partial) {
        $script:partialCount++
        Add-Report ('PARCIAL: algumas fontes nao responderam; codigo ' + $result.ExitCode + '.')
    } else {
        $script:okCount++
        Add-Report 'CONSULTA CONCLUIDA (dados declarados pelo Android).'
    }
    foreach ($item in $items) {
        # Output is inert text: strip controls and bound each field. Never execute it.
        $clean = [regex]::Replace([string] $item, '[\x00-\x1F\x7F]', ' ').Trim()
        if ($clean.Length -gt 240) { $clean = $clean.Substring(0, 240) + ' [truncado]' }
        if ($clean.Length -gt 0) { Add-Report $clean }
    }
}

try {
    Write-Host 'Diagnostico de leitura - TCL 50P8M' -ForegroundColor Cyan
    Write-Host 'TV: 192.168.1.102. Computador e TV devem estar na mesma rede.'
    Write-Host 'Este arquivo consulta informacoes; nao instala nem muda configuracoes.'
    Write-Host ''
    $directory = [System.IO.Path]::GetDirectoryName($env:TCL_DIAGNOSTIC_FILE)
    $script:adb = Join-Path $directory 'platform-tools\adb.exe'
    if (!(Test-Path -LiteralPath $script:adb -PathType Leaf)) {
        throw 'ADB nao encontrado. Clique em Extrair tudo no ZIP e abra Diagnosticar-TCL.cmd na pasta extraida, junto da pasta platform-tools.'
    }
    Write-Host 'Conectando. Se a TV pedir depuracao USB, aceite e marque Sempre permitir.'
    $connection = Invoke-Adb -Arguments @('connect', $serial)
    $state = Invoke-Adb -Arguments @('-s', $serial, 'get-state')
    if ($state.TimedOut -or $state.ExitCode -ne 0 -or $state.Text.Trim() -ne 'device') {
        $details = $connection.Text + $connection.ErrorText + $state.Text + $state.ErrorText
        if ($details -match 'unauthorized|authenticate|authentication') {
            throw 'A TV ainda nao autorizou este computador. Aceite Permitir depuracao USB na TV e abra este diagnostico novamente.'
        }
        if ($details -match 'offline') {
            throw 'A TV aparece offline. Confira se ela esta ligada e na mesma rede; depois abra este diagnostico novamente.'
        }
        throw 'Nao foi possivel conectar a TV. Confira TV ligada, depuracao USB ativa, IP 192.168.1.102 e mesma rede do computador. Envie uma foto desta janela.'
    }

    Add-Report 'DIAGNOSTICO DE LEITURA - TCL'
    Add-Report ('Gerado no horario local deste computador: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))
    Add-Report 'Alvo consultado: 192.168.1.102:5555'
    Add-Report 'Nenhuma configuracao da TV foi alterada por este diagnostico.'
    Add-Report 'Nao coleta senhas, chaves, contas, redes Wi-Fi, MACs, numero de serie ou dados privados de apps.'
    Add-Report 'Nao ha envio automatico. Revise este arquivo e envie-o na conversa para analise.'
    Add-Report 'Uma consulta indisponivel nao demonstra ausencia de suporte.'
    Add-Report 'Recursos, codecs e menus declarados nao garantem funcionamento em todos os aplicativos.'

    $properties = @(
        @('Fabricante', 'ro.product.manufacturer'),
        @('Modelo', 'ro.product.model'),
        @('Nome tecnico do dispositivo', 'ro.product.device'),
        @('Android', 'ro.build.version.release'),
        @('Nivel API', 'ro.build.version.sdk'),
        @('Patch de seguranca', 'ro.build.version.security_patch'),
        @('Identificacao publica do firmware', 'ro.build.display.id'),
        @('Fabricante do SoC', 'ro.soc.manufacturer'),
        @('Modelo do SoC', 'ro.soc.model'),
        @('Hardware Android', 'ro.hardware'),
        @('Plataforma da placa', 'ro.board.platform'),
        @('Arquiteturas de CPU para apps', 'ro.product.cpu.abilist'),
        @('Indicador Android de pouca RAM', 'ro.config.low_ram')
    )
    foreach ($property in $properties) {
        Read-Query -Title $property[0] -Command ('getprop ' + $property[1]) -Parser {
            param($raw)
            $line = $raw.Trim()
            if ($line.Length -gt 0 -and $line -notmatch '[\r\n]' -and
                $line -notmatch '^(error|exception|permission denied|unknown command)') { $line }
        }
    }

    Read-Query 'Memoria RAM relatada pelo kernel' 'cat /proc/meminfo' {
        param($raw)
        foreach ($line in ($raw -split '\r?\n')) {
            if ($line -match '^\s*(MemTotal|MemAvailable):\s+(\d+)\s+kB\s*$') {
                $matches[1] + ': ' + $matches[2] + ' kB'
            }
        }
    }
    Read-Query 'Armazenamento de dados (kB)' 'df -k /data' {
        param($raw)
        foreach ($line in ($raw -split '\r?\n')) {
            if ($line -match '^\S+\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)%\s+/data\s*$') {
                'Total=' + $matches[1] + '; usado=' + $matches[2] + '; livre=' + $matches[3] + '; uso=' + $matches[4] + '%; montagem=/data'
            }
        }
    }
    Read-Query 'Resolucao logica Android (nao confirma painel ou HDR)' 'wm size' {
        param($raw)
        foreach ($line in ($raw -split '\r?\n')) {
            if ($line -match '^\s*(Physical|Override) size:\s*(\d+)x(\d+)\s*$') {
                $matches[1] + ': ' + $matches[2] + 'x' + $matches[3]
            }
        }
    }
    Read-Query 'Densidade logica Android' 'wm density' {
        param($raw)
        foreach ($line in ($raw -split '\r?\n')) {
            if ($line -match '^\s*(Physical|Override) density:\s*(\d+)\s*$') {
                $matches[1] + ': ' + $matches[2] + ' dpi'
            }
        }
    }
    Read-Query 'Recursos declarados pelo Android' 'pm list features' {
        param($raw)
        if ($raw -notmatch '(?m)^feature:') { return }
        $wanted = @(
            'android.software.picture_in_picture', 'android.hardware.hdmi.cec',
            'android.hardware.usb.host', 'android.hardware.bluetooth',
            'android.hardware.bluetooth_le', 'android.software.leanback',
            'android.software.leanback_only', 'android.software.live_tv',
            'android.hardware.audio.output', 'android.hardware.wifi.direct'
        )
        foreach ($feature in $wanted) {
            if ($raw -match ('(?m)^feature:' + [regex]::Escape($feature) + '(?:=\S+)?\s*$')) {
                $feature + ': declarado'
            } else { $feature + ': nao consta nesta lista (nao prova ausencia)' }
        }
    }
    $menus = @(
        @('Menu geral de ajustes', 'android.settings.SETTINGS'),
        @('Menu de armazenamento', 'android.settings.INTERNAL_STORAGE_SETTINGS'),
        @('Menu de aplicativos', 'android.settings.APPLICATION_SETTINGS'),
        @('Menu Bluetooth', 'android.settings.BLUETOOTH_SETTINGS'),
        @('Menu de som', 'android.settings.SOUND_SETTINGS'),
        @('Menu de tela', 'android.settings.DISPLAY_SETTINGS'),
        @('Menu Picture-in-Picture', 'android.settings.PICTURE_IN_PICTURE_SETTINGS')
    )
    foreach ($menu in $menus) {
        Read-Query $menu[0] ('cmd package resolve-activity --brief -a ' + $menu[1]) {
            param($raw)
            foreach ($line in ($raw -split '\r?\n')) {
                if ($line.Trim() -match '^[A-Za-z][A-Za-z0-9_.]*/[A-Za-z0-9_.$]+$') { $line.Trim() }
            }
        }
    }
    Read-Query 'Codecs declarados nos arquivos de sistema (lista parcial)' "grep -h '<MediaCodec ' /system/etc/media_codecs.xml /vendor/etc/media_codecs.xml /odm/etc/media_codecs.xml 2>/dev/null" {
        param($raw)
        $found = @{}
        foreach ($entry in [regex]::Matches($raw, '<MediaCodec\b[^>]{1,500}>')) {
            $name = [regex]::Match($entry.Value, '\bname="([A-Za-z0-9_.:+-]{1,180})"')
            $type = [regex]::Match($entry.Value, '\btype="([A-Za-z0-9_./+-]{1,80})"')
            if ($name.Success) {
                $value = $name.Groups[1].Value
                if ($type.Success) { $value += ' | ' + $type.Groups[1].Value }
                $found[$value] = $true
            }
        }
        @($found.Keys | Sort-Object | Select-Object -First 100)
    } -PartialExitCodes @(2)
    Read-Query 'Indicadores HDR relatados pelo Android (nao confirma painel)' 'dumpsys display' {
        param($raw)
        $types = @{}
        $matched = $false
        foreach ($entry in [regex]::Matches($raw, '(?:mSupportedHdrTypes|supportedHdrTypes)\s*[:=]\s*\[([0-9, ]{0,80})\]')) {
            $matched = $true
            foreach ($number in [regex]::Matches($entry.Groups[1].Value, '\d+')) { $types[$number.Value] = $true }
        }
        if ($types.Count -gt 0) {
            'Tipos numericos declarados: ' + (($types.Keys | Sort-Object) -join ', ')
            'Convencao Android: 1=Dolby Vision; 2=HDR10; 3=HLG; 4=HDR10+.'
            'Esses indicadores podem incluir outras telas e nao garantem reproducao em um app.'
        } elseif ($matched) { 'Lista de tipos HDR vazia nesta resposta; nao permite concluir suporte do painel.' }
    }

    Add-Report ''
    Add-Report ('RESUMO: ' + $script:queryCount + ' consultas; ' + $script:okCount + ' concluidas; ' + $script:partialCount + ' parciais; ' + $script:unavailableCount + ' indisponiveis.')
    Add-Report 'Resultados indisponiveis e listas parciais devem ser investigados antes de recomendar recursos.'
    Add-Report 'Este relatorio nao altera nem testa a execucao dos recursos. Envie-o na conversa para analise.'
    $reportPath = Join-Path $directory 'Diagnostico-TCL.txt'
    if (Test-Path -LiteralPath $reportPath) {
        $reportPath = Join-Path $directory ('Diagnostico-TCL-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.txt')
    }
    $encoding = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllLines($reportPath, $script:report, $encoding)
    Write-Host ''
    Write-Host 'Relatorio criado:' -ForegroundColor Green
    Write-Host $reportPath
    Write-Host ('Consultas concluidas: ' + $script:okCount + '; parciais: ' + $script:partialCount + '; indisponiveis: ' + $script:unavailableCount)
    Write-Host 'Nenhum arquivo foi enviado automaticamente. Envie o TXT nesta conversa.'
    if ($script:okCount -eq 0 -and $script:partialCount -eq 0) {
        Write-Host 'As consultas ficaram indisponiveis. O relatorio registra essa limitacao.' -ForegroundColor Yellow
        exit 2
    }
    exit 0
} catch {
    Write-Host ''
    Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
