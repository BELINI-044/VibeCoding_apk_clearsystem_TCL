@echo off
setlocal DisableDelayedExpansion
set "FREEMYTV_INSTALLER_FILE=%~f0"
powershell.exe -NoLogo -NoProfile -Command "$text = [System.IO.File]::ReadAllText($env:FREEMYTV_INSTALLER_FILE); $marker = '# POWERSHELL_START'; $pos = $text.LastIndexOf($marker); if ($pos -lt 0) { Write-Host 'Arquivo instalador incompleto. Baixe o pacote novamente.'; exit 1 }; & ([ScriptBlock]::Create($text.Substring($pos + $marker.Length)))"
set "FREEMYTV_INSTALLER_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %FREEMYTV_INSTALLER_EXIT%
# POWERSHELL_START
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$serial = '192.168.1.102:5555'
$expectedHash = 'a6f6c0553c1ac14b7ff2d76c7c01d0d5782d5cf41caf42b100b93a0e7aec5f32'

function Invoke-Adb {
    param([string[]] $Arguments)
    # Windows PowerShell 5 turns native stderr into error records. Capture those
    # records as text, then use adb's own exit status to decide the result.
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $global:LASTEXITCODE = $null
        $lines = @(& $script:adb @Arguments 2>&1 | ForEach-Object { $_.ToString() })
        $code = if ($null -eq $LASTEXITCODE) { 1 } else { [int] $LASTEXITCODE }
    } finally {
        $ErrorActionPreference = $previousPreference
    }
    [PSCustomObject]@{ ExitCode = $code; Lines = $lines; Text = ($lines -join "`n") }
}

function Show-AdbOutput {
    param($Result)
    foreach ($line in $Result.Lines) { Write-Host $line }
}

try {
    Write-Host 'Atualizacao Free My TV - TCL 50P8M' -ForegroundColor Cyan
    Write-Host 'TV: 192.168.1.102. Deixe o computador e a TV na mesma rede.'
    Write-Host ''

    $directory = [System.IO.Path]::GetDirectoryName($env:FREEMYTV_INSTALLER_FILE)
    $script:adb = Join-Path $directory 'platform-tools\adb.exe'
    $apk = Join-Path $directory 'FreeMyTV-v2.apk'
    if (!(Test-Path -LiteralPath $script:adb -PathType Leaf) -or
        !(Test-Path -LiteralPath $apk -PathType Leaf)) {
        throw 'Arquivos do pacote nao encontrados. Feche esta janela, clique em Extrair tudo no ZIP e abra Atualizar-FreeMyTV.cmd na pasta extraida. Mantenha a pasta platform-tools e o APK junto do instalador.'
    }

    Write-Host 'Conferindo a integridade do APK...'
    $actualHash = (Get-FileHash -LiteralPath $apk -Algorithm SHA256).Hash
    if ($actualHash -ne $expectedHash) {
        throw 'O APK nao corresponde a esta atualizacao. A instalacao foi interrompida. Baixe e extraia novamente o pacote completo.'
    }

    Write-Host 'Conectando a TV. Se aparecer uma autorizacao de depuracao na TV, aceite.'
    $connection = Invoke-Adb -Arguments @('connect', $serial)
    Show-AdbOutput $connection
    $state = Invoke-Adb -Arguments @('-s', $serial, 'get-state')
    $stateLines = @($state.Lines | Where-Object { $_.Trim().Length -gt 0 })
    $ready = $state.ExitCode -eq 0 -and $stateLines.Count -gt 0 -and
             $stateLines[-1].Trim() -eq 'device'
    if (!$ready) {
        Show-AdbOutput $state
        $details = $connection.Text + "`n" + $state.Text
        if ($details -match 'unauthorized|authenticate|authentication') {
            throw 'A TV ainda nao autorizou este computador. Na TV, aceite Permitir depuracao USB e marque Sempre permitir. Depois abra este instalador novamente.'
        }
        if ($details -match 'offline') {
            throw 'A TV aparece offline. Verifique se ela esta ligada e se o computador continua na mesma rede; depois abra este instalador novamente.'
        }
        throw 'Nao foi possivel conectar a TV. Confira se ela esta ligada, com depuracao USB ativa, IP 192.168.1.102 e na mesma rede do computador. Envie uma foto desta janela para receber ajuda.'
    }

    Write-Host ''
    Write-Host 'Instalando a atualizacao. Aguarde; confira a TV se surgir uma confirmacao.'
    $installation = Invoke-Adb -Arguments @('-s', $serial, 'install', '-r', $apk)
    Show-AdbOutput $installation
    $successLines = @($installation.Lines | Where-Object { $_.Trim() -eq 'Success' })
    if ($installation.ExitCode -ne 0 -or $successLines.Count -eq 0) {
        if ($installation.Text -match 'INSTALL_FAILED_UPDATE_INCOMPATIBLE') {
            throw 'A assinatura do aplicativo instalado e diferente. Nao desinstale o aplicativo. Envie uma foto desta janela para receber ajuda.'
        }
        if ($installation.Text -match 'INSTALL_FAILED_VERSION_DOWNGRADE') {
            throw 'A TV ja possui uma versao mais recente. Nao remova o aplicativo nem seus dados. Envie uma foto desta janela.'
        }
        if ($installation.Text -match 'INSTALL_FAILED_INSUFFICIENT_STORAGE') {
            throw 'A TV informou falta de espaco. A atualizacao nao foi concluida. Envie uma foto desta janela.'
        }
        throw 'Nao foi possivel confirmar a instalacao. Confira se ha uma mensagem na TV e envie uma foto desta janela. O instalador nao vai tentar novamente sozinho.'
    }

    Write-Host ''
    Write-Host 'Success - atualizacao instalada!' -ForegroundColor Green
    Write-Host 'Agora pressione Home no controle da TV e confira a nova interface.'
    Write-Host 'Envie uma foto da tela inicial para avaliarmos o resultado.'
    exit 0
} catch {
    Write-Host ''
    Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
